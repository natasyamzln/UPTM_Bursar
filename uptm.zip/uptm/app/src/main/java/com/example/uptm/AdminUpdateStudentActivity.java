package com.example.uptm;

import static android.content.ContentValues.TAG;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;

import java.text.DateFormat;
import java.text.DecimalFormat;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class AdminUpdateStudentActivity extends AppCompatActivity {

    Button save, delete;
//    EditText txtMatrixNumber,txtName;

    EditText txtName, txtAddress,txtUsername,txtPassword,txtCompound;
    Spinner spinnerCurrentSemester, spinnerType;
    LinearLayout checkBoxContainer;
    ProgressDialog progressDialog;
//    DatabaseReference ref;
    String Fid;
    List<Boolean> semesterPaid = null;

    boolean[] semesterPaidArray;

    int semesterNum = 10;

    String newSelectedCurrentSemester;
    String newSelectedType;

    String[] numberOfSemesterChoices = {"Currently semester 1", "Currently semester 2", "Currently semester 3", "Currently semester 4", "Currently semester 5", "Currently semester 6", "Currently semester 7", "Currently semester 8", "Currently semester 9", "Currently semester 10"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_update_student);

//        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
//        getSupportActionBar().setTitle("Add Student Page");
        delete = findViewById(R.id.btnDelete);
        save = findViewById(R.id.btnSave);
//        txtMatrixNumber = findViewById(R.id.txtMatrix);
        txtName = findViewById(R.id.txtName);
        txtAddress = findViewById(R.id.txtAddress);
        txtUsername = findViewById(R.id.txtUsername);
        txtPassword = findViewById(R.id.txtPassword);
        txtCompound = findViewById(R.id.txtCompound);

        spinnerCurrentSemester = findViewById(R.id.spinnerCurrentSemester);


        spinnerType = findViewById(R.id.spinnerType);

        checkBoxContainer = findViewById(R.id.checkBoxContainer);

        progressDialog = new ProgressDialog(this);
        progressDialog.setTitle("Please Wait..");
        progressDialog.setCanceledOnTouchOutside(false);

        String name = getIntent().getStringExtra("name");
        txtName.setText(name);
        String username = getIntent().getStringExtra("username");
        txtUsername.setText(username);
        String password = getIntent().getStringExtra("password");
        txtPassword.setText(password);
        String currentSemester = getIntent().getStringExtra("currentSemester");

        String type = getIntent().getStringExtra("type");
        String address = getIntent().getStringExtra("address");
        txtAddress.setText(address);
        double compound = getIntent().getDoubleExtra("compound", 0.0); // Default value 0.0 if not found
        txtCompound.setText(new DecimalFormat("0.00").format(compound));

        // Retrieve the wrapped list of booleans
        BooleanListWrapper wrapper = getIntent().getParcelableExtra("semesterPaid");

        if (wrapper != null) {
            semesterPaid = wrapper.getBooleanList();
            for (Boolean b : semesterPaid) {
                System.out.println("paid: "+b.toString());
            }
        }
        if(type.equals("Diploma")){
            semesterNum = 10;
            setupCheckBoxes(semesterNum,semesterPaid);
            // Update the number of semester choices for the spinner
            numberOfSemesterChoices = new String[]{"Currently semester 1", "Currently semester 2", "Currently semester 3", "Currently semester 4", "Currently semester 5", "Currently semester 6", "Currently semester 7", "Currently semester 8", "Currently semester 9", "Currently semester 10"};
        }
        else if(type.equals("Degree")){
            semesterNum = 12;
            setupCheckBoxes(semesterNum,semesterPaid);
            // Update the number of semester choices for the spinner
            numberOfSemesterChoices = new String[]{"Currently semester 1", "Currently semester 2", "Currently semester 3", "Currently semester 4", "Currently semester 5", "Currently semester 6", "Currently semester 7", "Currently semester 8", "Currently semester 9", "Currently semester 10", "Currently semester 11", "Currently semester 12"};
        }
        else if(type.equals("Professionals")){
            semesterNum = 11;
            setupCheckBoxes(semesterNum,semesterPaid);
            // Update the number of semester choices for the spinner
            numberOfSemesterChoices = new String[]{"Currently semester 1", "Currently semester 2", "Currently semester 3", "Currently semester 4", "Currently semester 5", "Currently semester 6", "Currently semester 7", "Currently semester 8", "Currently semester 9", "Currently semester 10", "Currently semester 11"};
        }
        String[] studentTypesArray = getResources().getStringArray(R.array.student_types_array);

        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
                R.array.student_types_array, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerType.setAdapter(adapter);

        int currentTypeIndex = Arrays.asList(studentTypesArray).indexOf(toCamelCase(type));
        System.out.println("toCamelCase(type): "+toCamelCase(type));
        System.out.println("currentTypeIndex: "+currentTypeIndex);
        System.out.println("type: "+type);
        System.out.println("R.array.student_types_array: "+Arrays.toString(studentTypesArray));
//        System.out.println("\"Currently semester \" + String.valueOf((int) Float.parseFloat(currentSemester)): " + "Currently semester " + String.valueOf((int) Float.parseFloat(currentSemester)));
        spinnerType.setSelection(currentTypeIndex);
        spinnerType.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                newSelectedType = adapterView.getItemAtPosition(i).toString();
                if(newSelectedType.equals("Diploma")){
                    semesterNum = 10;
                    setupCheckBoxes(semesterNum,semesterPaid);
                    // Update the number of semester choices for the spinner
                    numberOfSemesterChoices = new String[]{"Currently semester 1", "Currently semester 2", "Currently semester 3", "Currently semester 4", "Currently semester 5", "Currently semester 6", "Currently semester 7", "Currently semester 8", "Currently semester 9", "Currently semester 10"};
                }
                else if(newSelectedType.equals("Degree")){
                    semesterNum = 12;
                    setupCheckBoxes(semesterNum,semesterPaid);
                    // Update the number of semester choices for the spinner
                    numberOfSemesterChoices = new String[]{"Currently semester 1", "Currently semester 2", "Currently semester 3", "Currently semester 4", "Currently semester 5", "Currently semester 6", "Currently semester 7", "Currently semester 8", "Currently semester 9", "Currently semester 10", "Currently semester 11", "Currently semester 12"};
                }
                else if(newSelectedType.equals("Professionals")){
                    semesterNum = 11;
                    setupCheckBoxes(semesterNum,semesterPaid);
                    // Update the number of semester choices for the spinner
                    numberOfSemesterChoices = new String[]{"Currently semester 1", "Currently semester 2", "Currently semester 3", "Currently semester 4", "Currently semester 5", "Currently semester 6", "Currently semester 7", "Currently semester 8", "Currently semester 9", "Currently semester 10", "Currently semester 11"};
                }
                ArrayAdapter ad = new ArrayAdapter(getApplicationContext(), android.R.layout.simple_spinner_item, numberOfSemesterChoices);
                ad.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                spinnerCurrentSemester.setAdapter(ad);
                int currentSemesterIndex = Arrays.asList(numberOfSemesterChoices).indexOf("Currently semester " + String.valueOf((int) Float.parseFloat(currentSemester)));
                spinnerCurrentSemester.setSelection(currentSemesterIndex);
                System.out.println("Selected: " + newSelectedType);
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });

        ArrayAdapter ad = new ArrayAdapter(this,android.R.layout.simple_spinner_item,numberOfSemesterChoices);
        ad.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerCurrentSemester.setAdapter(ad);
        // Find the index of the current semester in the numberOfSemesterChoices array
        int currentSemesterIndex = Arrays.asList(numberOfSemesterChoices).indexOf("Currently semester " + String.valueOf((int) Float.parseFloat(currentSemester)));
        System.out.println("currentSemesterIndex: "+currentSemesterIndex);
        System.out.println("currentSemester: "+currentSemester);
        System.out.println("numberOfSemesterChoices: "+ Arrays.toString(numberOfSemesterChoices));
        System.out.println("\"Currently semester \" + String.valueOf((int) Float.parseFloat(currentSemester)): " + "Currently semester " + String.valueOf((int) Float.parseFloat(currentSemester)));
        // Set the spinner selection to the current semester index
        spinnerCurrentSemester.setSelection(currentSemesterIndex);
        spinnerCurrentSemester.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                newSelectedCurrentSemester = numberOfSemesterChoices[i];
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {
                newSelectedCurrentSemester = String.valueOf((int) Float.parseFloat(currentSemester));
            }
        });
        txtName.setText(name);


        save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                validateData();
            }
        });

        delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                deleteStu(username);

            }
        });

    }

    private void validateData() {

        String Name = txtName.getText().toString().trim();
        String username = txtUsername.getText().toString().trim();
        String password = txtPassword.getText().toString().trim();
        String address = txtAddress.getText().toString().trim();


        if (TextUtils.isEmpty(Name) || TextUtils.isEmpty(username) || TextUtils.isEmpty(password) || TextUtils.isEmpty(address)) {
            Toast.makeText(this, "All fields are required.", Toast.LENGTH_SHORT).show();
        } else {
            uploadData();
        }


    }

    private void uploadData() {

        progressDialog.setMessage("Saving Student Details...");
        progressDialog.show();

        String username = txtUsername.getText().toString();
        String password = txtPassword.getText().toString();
        String address = txtAddress.getText().toString();
        String name = txtName.getText().toString();
        String currentSemester = spinnerCurrentSemester.getSelectedItem().toString();
        currentSemester = currentSemester.replace("Currently semester ","");
        String type = spinnerType.getSelectedItem().toString();
        double compound = Double.parseDouble(txtCompound.getText().toString());


        Map<String, Object> studentData = new HashMap<>();
        studentData.put("username", username);
        studentData.put("password", password);
        studentData.put("address", address);
        studentData.put("name", name);
        studentData.put("currentSemester", currentSemester);
        studentData.put("type", type.toLowerCase().toString());
        studentData.put("compound", compound);
        studentData.put("semesterPaid", semesterPaid);

        System.out.println(studentData.toString());
        FirebaseFirestore db = FirebaseFirestore.getInstance();

        DocumentReference usersRef = db.collection("users").document(username);


        usersRef
                .update(studentData)
                .addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void aVoid) {
                        Log.d(TAG, "DocumentSnapshot successfully updated!");
                        progressDialog.cancel();
                        Toast.makeText(AdminUpdateStudentActivity.this, "Student Details Updated...", Toast.LENGTH_SHORT).show();
                        finish();
                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Log.w(TAG, "Error updating document", e);
                        progressDialog.cancel();
                        Toast.makeText(AdminUpdateStudentActivity.this, "Error Updating Student Details ...", Toast.LENGTH_SHORT).show();
                        finish();
                    }
                });


    }


    private void deleteStu(String username){
        progressDialog.setMessage("Deleting Student");
        progressDialog.show();

        FirebaseFirestore db = FirebaseFirestore.getInstance();
        db.collection("users").document(username)
                .delete()
                .addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void aVoid) {
                        Log.d(TAG, "DocumentSnapshot successfully deleted!");
                        progressDialog.cancel();
                        Toast.makeText(AdminUpdateStudentActivity.this, "Student Deleted...", Toast.LENGTH_SHORT).show();
                        finish();
                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Log.w(TAG, "Error deleting document", e);
                        progressDialog.cancel();
                        Toast.makeText(AdminUpdateStudentActivity.this, "Error Deleting Student ...", Toast.LENGTH_SHORT).show();
                        finish();
                    }
                });

    }



    private void createCheckBoxes(int numSemesters, List<Boolean> semesterPaid) {
        // Ensure that semesterPaid list is initialized with false values for all semesters up to numSemesters
        while (semesterPaid.size() < numSemesters) {
            semesterPaid.add(false);
        }

        LinearLayout checkBoxContainer = findViewById(R.id.checkBoxContainer);

        // Clear existing checkboxes if any
        checkBoxContainer.removeAllViews();

        // Create and add checkboxes for each semester
        for (int i = 0; i < numSemesters; i++) {
            CheckBox checkBox = new CheckBox(this);
            checkBox.setText("Semester " + (i + 2) + " paid");
            checkBox.setChecked(semesterPaid.get(i)); // Set checkbox state based on semesterPaid value

            // Set a tag to identify which semester this checkbox represents
            checkBox.setTag(i);

            // Add a listener to update the corresponding value in the semesterPaid list when the checkbox state changes
            checkBox.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                @Override
                public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                    // Get the tag (semester index) of the checkbox
                    int semesterIndex = (int) buttonView.getTag();

                    // Update the corresponding value in the semesterPaid list
                    semesterPaid.set(semesterIndex, isChecked);
                }
            });

            // Add the checkbox to the layout
            checkBoxContainer.addView(checkBox);
        }
    }

    private void setupCheckBoxes(int numSemesters,List<Boolean> semesterPaid) {
        createCheckBoxes(numSemesters,semesterPaid);
    }
    public static String toCamelCase(String input) {
        // Split the input string into words using space as the delimiter
        String[] words = input.split("\\s+");

        StringBuilder camelCase = new StringBuilder();

        // Capitalize the first letter of each word and append to camelCase
        for (String word : words) {
            if (!word.isEmpty()) {
                camelCase.append(Character.toUpperCase(word.charAt(0)))
                        .append(word.substring(1).toLowerCase());
            }
        }

        return camelCase.toString();
    }

}