package com.example.uptm;

import static android.content.ContentValues.TAG;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.icu.util.Output;
import android.os.Bundle;
import android.os.Environment;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;
import com.itextpdf.io.image.ImageData;
import com.itextpdf.io.image.ImageDataFactory;
import com.itextpdf.kernel.colors.DeviceRgb;
import com.itextpdf.kernel.pdf.PdfDocument;
import com.itextpdf.kernel.pdf.PdfWriter;
import com.itextpdf.layout.Document;
import com.itextpdf.layout.borders.Border;
import com.itextpdf.layout.element.Cell;
import com.itextpdf.layout.element.Image;
import com.itextpdf.layout.element.Paragraph;
import com.itextpdf.layout.element.Table;
import com.itextpdf.layout.property.HorizontalAlignment;
import com.itextpdf.layout.property.TextAlignment;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.text.DecimalFormat;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.List;

public class StudentTotalDuesActivity extends AppCompatActivity {

    Button payBtn,invoiceBtn;
    TextView textViewAmount;
    ProgressBar indeterminateBar;

    private FirebaseFirestore mFirestore;
    private static final String TAG = "uptmSnippets";

    String nameFromFirestore = "";
    String addressFromFirestore = "";
    String currentSemesterFromFirestore = "";
    String typeFromFirestore = "";
    String usernameFromFirestore = "";
    boolean[] semesterPaidFromFirestore = {};
    double compound = 0;

    boolean paid = false;

    double priceSemester = 0;

    List<Boolean> semesterPaidList;

    DecimalFormat df = new DecimalFormat("0.00");

    double[] pricesDiploma = {270.00, 260.00, 310.00, 260.00,260.00, 50.00, 260.00, 260.00, 310.00};
    double[] pricesDegree = {260.00, 260.00, 310.00, 260.00,260.00, 310.00, 260.00, 260.00,310.00, 260.00, 260.00};
    double[] pricesProfessional = {280.00, 330.00, 280.00, 330.00, 280.00, 330.00, 280.00, 330.00, 280.00, 330.00};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_student_total_dues);

        String idValue = getIntent().getStringExtra("idValue");
        System.out.println("idValue received in StudentTotalDuesActivity: " + idValue);

        payBtn = findViewById(R.id.button);
        payBtn.setEnabled(false);
        invoiceBtn = findViewById(R.id.button2);
        invoiceBtn.setEnabled(false);
        textViewAmount = findViewById(R.id.textView3);

        indeterminateBar = findViewById(R.id.indeterminateBar);
        indeterminateBar.setVisibility(View.VISIBLE);

        mFirestore = FirebaseFirestore.getInstance();
        mFirestore.collection("users")
                .get()
                .addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                    @Override
                    public void onComplete(@NonNull Task<QuerySnapshot> task) {
                        if (task.isSuccessful()) {
                            for (QueryDocumentSnapshot document : task.getResult()) {
                                Log.d(TAG, document.getId() + " => " + document.getData());

                                if(document.getId().equals(idValue)){
                                    System.out.println("matches: " + idValue);
                                    nameFromFirestore = document.getString("name");
                                    addressFromFirestore = document.getString("address");
                                    currentSemesterFromFirestore = document.getString("currentSemester");
                                    typeFromFirestore = document.getString("type");
                                    usernameFromFirestore = document.getString("username");
                                    compound = document.getDouble("compound");
                                    // Retrieve semesterPaid array as a List<Boolean> and convert it to a boolean array
                                    semesterPaidList = (List<Boolean>) document.get("semesterPaid");
                                    if (semesterPaidList != null && !semesterPaidList.isEmpty()) {
                                        System.out.println("TRUE semesterPaidList != null && !semesterPaidList.isEmpty()");
                                        semesterPaidFromFirestore = new boolean[semesterPaidList.size()];
                                        for (int i = 0; i < semesterPaidList.size(); i++) {
                                            semesterPaidFromFirestore[i] = semesterPaidList.get(i);
                                            System.out.println("semesterPaidFromFirestore[i] " + String.valueOf(i)+ ": " + String.valueOf(semesterPaidFromFirestore[i]) );
                                        }
                                        if(Integer.valueOf(currentSemesterFromFirestore)>1){
                                            System.out.println("TRUE Integer.valueOf(currentSemesterFromFirestore)>1");
                                            if(semesterPaidFromFirestore[Integer.valueOf(currentSemesterFromFirestore)-2] == true){
                                                System.out.println("TRUE semesterPaidFromFirestore[Integer.valueOf(currentSemesterFromFirestore)-2] == true");
                                                paid = true;
                                            }
                                            else{
                                                System.out.println("FALSE semesterPaidFromFirestore[Integer.valueOf(currentSemesterFromFirestore)-2] == true");
                                                System.out.println("currentSemesterFromFirestore: " + currentSemesterFromFirestore);
                                                System.out.println("semesterPaidFromFirestore[Integer.valueOf(currentSemesterFromFirestore)-2]: " + String.valueOf(semesterPaidFromFirestore[Integer.valueOf(currentSemesterFromFirestore)-2]));
                                            }
                                        }
                                        else{
                                            System.out.println("FALSE Integer.valueOf(currentSemesterFromFirestore)>1");
                                            paid = true;
                                        }

                                    }
                                    else{
                                        System.out.println("FALSE semesterPaidList != null && !semesterPaidList.isEmpty()");
                                    }


                                    if(!paid){
                                        if (typeFromFirestore.equals("diploma")) {
                                            switch (currentSemesterFromFirestore) {
                                                case "2":
                                                    priceSemester = 270.00;
                                                    break;
                                                case "3":
                                                case "5":
                                                case "6":
                                                case "8":
                                                case "9":
                                                    priceSemester = 260.00;
                                                    break;
                                                case "4":
                                                case "10":
                                                    priceSemester = 310.00;
                                                    break;
                                                case "7":
                                                    priceSemester = 50.00;
                                                    break;
                                                default:
                                                    // Handle unexpected semester values
                                                    break;
                                            }
                                        } else if (typeFromFirestore.equals("degree")) {
                                            System.out.println("degree");
                                            System.out.println("currentSemesterFromFirestore: " + currentSemesterFromFirestore);
                                            switch (currentSemesterFromFirestore) {
                                                case "2":
                                                case "12":
                                                case "11":
                                                case "9":
                                                case "8":
                                                case "6":
                                                case "5":
                                                case "3":

                                                    priceSemester = 260.00;
                                                    break;
                                                case "4":
                                                case "10":
                                                case "7":
                                                    priceSemester = 310.00;
                                                    break;
                                                default:
                                                    // Handle unexpected semester values
                                                    break;
                                            }
                                            System.out.println("priceSemester: " + String.valueOf(priceSemester));
                                        } else if (typeFromFirestore.equals("professional")) {
                                            switch (currentSemesterFromFirestore) {
                                                case "2":
                                                case "4":
                                                case "6":
                                                case "8":
                                                case "10":
                                                    priceSemester = 280.00;
                                                    break;
                                                case "3":
                                                case "5":
                                                case "7":
                                                case "9":
                                                case "11":
                                                    priceSemester = 330.00;
                                                    break;
                                                default:
                                                    // Handle unexpected semester values
                                                    break;
                                            }
                                        }

                                        textViewAmount.setText("RM " + df.format(priceSemester+compound));
                                        invoiceBtn.setEnabled(true);
                                        payBtn.setEnabled(true);
                                    }
                                    else{
                                        priceSemester = 0;
                                        textViewAmount.setText("RM " + df.format(priceSemester));
                                    }
                                    indeterminateBar.setVisibility(View.GONE);
                                    break;
                                }
                                else{
                                    System.out.println("not match: " + idValue);
                                }
                            }
                        } else {
                            Log.d(TAG, "Error getting documents: ", task.getException());
                        }
                    }
                });




        invoiceBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try {
                    indeterminateBar.setVisibility(View.VISIBLE);
                    invoiceBtn.setEnabled(false);
                    if(nameFromFirestore.equals("") && addressFromFirestore.equals("")&&currentSemesterFromFirestore.equals("")&&typeFromFirestore.equals("")){

                        System.out.println("Empty nameFromFirestore.equals() && addressFromFirestore.equals()&&currentSemesterFromFirestore.equals()");
                    }
                    else{
                        createPdf(nameFromFirestore,addressFromFirestore,currentSemesterFromFirestore,priceSemester,compound,typeFromFirestore);

                    }
                    indeterminateBar.setVisibility(View.GONE);
                    invoiceBtn.setEnabled(true);

                } catch (FileNotFoundException e) {
                    throw new RuntimeException(e);
                }
            }
        });

        payBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                indeterminateBar.setVisibility(View.VISIBLE);
                payBtn.setEnabled(false);
                payment(usernameFromFirestore,typeFromFirestore,currentSemesterFromFirestore,semesterPaidList);
                indeterminateBar.setVisibility(View.GONE);
            }
        });
    }

    private void payment(String usernameFromFirestore,String typeFromFirestore,String currentSemesterFromFirestore, List<Boolean> semesterPaidList ){
        DocumentReference usersRef = FirebaseFirestore.getInstance().collection("users").document(usernameFromFirestore);
        int indexPay = 0;
        switch (currentSemesterFromFirestore) {
            case "2":
                indexPay = 0;
                break;
            case "3":
                indexPay = 1;
                break;
            case "4":
                indexPay = 2;
                break;
            case "5":
                indexPay = 3;
                break;
            case "6":
                indexPay = 4;
                break;
            case "7":
                indexPay = 5;
                break;
            case "8":
                indexPay = 6;
                break;
            case "9":
                indexPay = 7;
                break;
            case "10":
                indexPay = 8;
                break;
            case "11":
                indexPay = 9;
                break;
            case "12":
                indexPay = 10;
                break;
            default:
                // Handle unexpected semester values
                break;
        }


        semesterPaidList.set(indexPay,true);

        usersRef
                .update("semesterPaid",semesterPaidList)
                .addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void aVoid) {
                        Log.d(TAG, "DocumentSnapshot successfully updated!");
                        Toast.makeText(StudentTotalDuesActivity.this, "Payment successful", Toast.LENGTH_SHORT).show();
                        finish();
                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Log.w(TAG, "Error updating document", e);
                        Toast.makeText(StudentTotalDuesActivity.this, "Error Updating Student Details ...", Toast.LENGTH_SHORT).show();
                        finish();
                    }
                });
    }

    private void createPdf(String studentName,String address,String semesterNum,double semesterPrice, double compoundPrice, String type) throws FileNotFoundException{

        // Get current date
        LocalDate currentDate = LocalDate.now();

        // Format the date as a string
        DateTimeFormatter dateFormatter = DateTimeFormatter.ofPattern("dd-MM-yyyy");
        String dateString = dateFormatter.format(currentDate);

        // Get current time
        LocalTime currentTime = LocalTime.now();

        // Format the time as a string
        DateTimeFormatter timeFormatter = DateTimeFormatter.ofPattern("HH:mm:ss");
        String timeString = timeFormatter.format(currentTime);

        // Print the current date and time as strings
        System.out.println("Current Date: " + dateString);
        System.out.println("Current Time: " + timeString);
        String pdfPath = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS).toString();
        File file = new File(pdfPath,"myPDF.pdf");
        OutputStream outputStream =  new FileOutputStream(file);

        PdfWriter writer = new PdfWriter(file);
        PdfDocument pdfDocument = new PdfDocument(writer);
        Document document = new Document(pdfDocument);

        DeviceRgb invoiceGreen = new DeviceRgb(51,204,51);
        DeviceRgb invoiceGray = new DeviceRgb(220,220,220);

        float columnWidth[] = {140,140,140,140};
        Table table1 = new Table(columnWidth);

        //Table-----01
        Drawable d1 = getDrawable(R.drawable.logo);
        Bitmap bitmap1 = ((BitmapDrawable)d1).getBitmap();
        ByteArrayOutputStream stream1 = new ByteArrayOutputStream();
        bitmap1.compress(Bitmap.CompressFormat.PNG, 100,stream1);
        byte[] bitmapData1 = stream1.toByteArray();
        ImageData imageData1 = ImageDataFactory.create(bitmapData1);
        Image image1 = new Image(imageData1);
        image1.setHeight(100f);

        table1.addCell(new Cell(4,1).add(image1).setBorder(Border.NO_BORDER));
        table1.addCell(new Cell().add(new Paragraph("")).setBorder(Border.NO_BORDER));
        table1.addCell(new Cell(1,2).add(new Paragraph("Invoice").setFontSize(26f)).setBorder(Border.NO_BORDER));
//        table1.addCell(new Cell().add(new Paragraph("")));

        //Table-----02
//        table1.addCell(new Cell().add(new Paragraph("")));
        table1.addCell(new Cell().add(new Paragraph("")).setBorder(Border.NO_BORDER));
        table1.addCell(new Cell().add(new Paragraph("Invoice No:")).setBorder(Border.NO_BORDER));
        table1.addCell(new Cell().add(new Paragraph("#123456789")).setBorder(Border.NO_BORDER));

        //Table-----03
//        table1.addCell(new Cell().add(new Paragraph("")));
        table1.addCell(new Cell().add(new Paragraph("")).setBorder(Border.NO_BORDER));
        table1.addCell(new Cell().add(new Paragraph("Invoice Date:")).setBorder(Border.NO_BORDER));
        table1.addCell(new Cell().add(new Paragraph(dateString)).setBorder(Border.NO_BORDER));

        //Table-----04
//        table1.addCell(new Cell().add(new Paragraph("")));
        table1.addCell(new Cell().add(new Paragraph("")).setBorder(Border.NO_BORDER));
        table1.addCell(new Cell().add(new Paragraph("Account No:")).setBorder(Border.NO_BORDER));
        table1.addCell(new Cell().add(new Paragraph("1234567890")).setBorder(Border.NO_BORDER));

        //Table-----05
        table1.addCell(new Cell().add(new Paragraph("\n")).setBorder(Border.NO_BORDER));
        table1.addCell(new Cell().add(new Paragraph("")).setBorder(Border.NO_BORDER));
        table1.addCell(new Cell().add(new Paragraph("")).setBorder(Border.NO_BORDER));
        table1.addCell(new Cell().add(new Paragraph("")).setBorder(Border.NO_BORDER));

        //Table-----06
        table1.addCell(new Cell().add(new Paragraph("To")).setBorder(Border.NO_BORDER));
        table1.addCell(new Cell().add(new Paragraph("")).setBorder(Border.NO_BORDER));
        table1.addCell(new Cell().add(new Paragraph("")).setBorder(Border.NO_BORDER));
        table1.addCell(new Cell().add(new Paragraph("")).setBorder(Border.NO_BORDER));

        //Table-----07
        table1.addCell(new Cell().add(new Paragraph(studentName)).setBorder(Border.NO_BORDER));
        table1.addCell(new Cell().add(new Paragraph("")).setBorder(Border.NO_BORDER));
        table1.addCell(new Cell().add(new Paragraph("Payment Method:").setBold()).setBorder(Border.NO_BORDER));
        table1.addCell(new Cell().add(new Paragraph("")).setBorder(Border.NO_BORDER));

        //Table-----08
        table1.addCell(new Cell().add(new Paragraph(address)).setBorder(Border.NO_BORDER));
        table1.addCell(new Cell().add(new Paragraph("")).setBorder(Border.NO_BORDER));
        table1.addCell(new Cell(1,2).add(new Paragraph("Paypal: payments@uptmexample.com")).setBorder(Border.NO_BORDER));
//        table1.addCell(new Cell().add(new Paragraph("")));

        //Table-----09
        table1.addCell(new Cell().add(new Paragraph("Malaysia")).setBorder(Border.NO_BORDER));
        table1.addCell(new Cell().add(new Paragraph("")).setBorder(Border.NO_BORDER));
        table1.addCell(new Cell(1,2).add(new Paragraph("Card Payment: We accept Visa, Mastercard")).setBorder(Border.NO_BORDER));
//        table1.addCell(new Cell().add(new Paragraph("")));

        float columnWidth2[] = {62,162,112,112};
        Table table2 = new Table(columnWidth2);

        //Table 2 ----- 01
        table2.addCell(new Cell().add(new Paragraph("No.")));
        table2.addCell(new Cell().add(new Paragraph("SEMESTER")));
//        table2.addCell(new Cell().add(new Paragraph("RATE")));
        table2.addCell(new Cell().add(new Paragraph("")));
        table2.addCell(new Cell().add(new Paragraph("PRICE(RM)")));

        //Table 2 ----- 02
        table2.addCell(new Cell().add(new Paragraph("1.")));
        table2.addCell(new Cell().add(new Paragraph("Semester " + semesterNum + " " + type.toUpperCase().toString())));
//        table2.addCell(new Cell().add(new Paragraph("50")));
        table2.addCell(new Cell().add(new Paragraph("")));
        table2.addCell(new Cell().add(new Paragraph(df.format(semesterPrice))));

        //Table 2 ----- 03
//        table2.addCell(new Cell().add(new Paragraph("")));
//        table2.addCell(new Cell().add(new Paragraph("")));
//        table2.addCell(new Cell().add(new Paragraph("")));
//        table2.addCell(new Cell().add(new Paragraph("")));
//        table2.addCell(new Cell().add(new Paragraph("")));
//
//        //Table 2 ----- 04
//        table2.addCell(new Cell().add(new Paragraph("")));
//        table2.addCell(new Cell().add(new Paragraph("")));
//        table2.addCell(new Cell().add(new Paragraph("")));
//        table2.addCell(new Cell().add(new Paragraph("")));
//        table2.addCell(new Cell().add(new Paragraph("")));
//
//        //Table 2 ----- 05
//        table2.addCell(new Cell().add(new Paragraph("")));
//        table2.addCell(new Cell().add(new Paragraph("")));
//        table2.addCell(new Cell().add(new Paragraph("")));
//        table2.addCell(new Cell().add(new Paragraph("")));
//        table2.addCell(new Cell().add(new Paragraph("")));

        //Table 2 ----- 06
        table2.addCell(new Cell().add(new Paragraph("")));
        table2.addCell(new Cell().add(new Paragraph("")));
//        table2.addCell(new Cell().add(new Paragraph("")));
        table2.addCell(new Cell().add(new Paragraph("Sub-Total")));
        table2.addCell(new Cell().add(new Paragraph(df.format(semesterPrice))));

        //Table 2 ----- 07
        table2.addCell(new Cell(1,2).add(new Paragraph("Terms & Conditions:")));
//        table2.addCell(new Cell().add(new Paragraph("")));
//        table2.addCell(new Cell().add(new Paragraph("")));
        table2.addCell(new Cell().add(new Paragraph("Compound")));
        table2.addCell(new Cell().add(new Paragraph(df.format(compoundPrice))));

        //Table 2 ----- 08
        double grandTotal = semesterPrice + compoundPrice;
        table2.addCell(new Cell(1,2).add(new Paragraph("No refunds")));
//        table2.addCell(new Cell().add(new Paragraph("")));
//        table2.addCell(new Cell().add(new Paragraph("")));
        table2.addCell(new Cell().add(new Paragraph("Grand Total")));
        table2.addCell(new Cell().add(new Paragraph(df.format(grandTotal))));

        float columnWidth3[]={50,250,260};
        Table table3 = new Table(columnWidth3);

        Drawable d2 = getDrawable(R.drawable.dues);
        Bitmap bitmap2 = ((BitmapDrawable)d2).getBitmap();
        ByteArrayOutputStream stream2 = new ByteArrayOutputStream();
        bitmap2.compress(Bitmap.CompressFormat.PNG, 100,stream2);
        byte[] bitmapData2 = stream2.toByteArray();
        ImageData imageData2 = ImageDataFactory.create(bitmapData2);
        Image image2 = new Image(imageData2);
        image2.setHeight(120);

        Drawable d3 = getDrawable(R.drawable.dues);
        Bitmap bitmap3 = ((BitmapDrawable)d3).getBitmap();
        ByteArrayOutputStream stream3 = new ByteArrayOutputStream();
        bitmap3.compress(Bitmap.CompressFormat.PNG, 100,stream3);
        byte[] bitmapData3 = stream3.toByteArray();
        ImageData imageData3 = ImageDataFactory.create(bitmapData3);
        Image image3 = new Image(imageData3);
        image3.setHeight(120);
        image3.setHorizontalAlignment(HorizontalAlignment.RIGHT);

        table3.addCell(new Cell(3,1).add(new Paragraph("")).setBorder(Border.NO_BORDER));
        table3.addCell(new Cell().add(new Paragraph("")).setBorder(Border.NO_BORDER));
        table3.addCell(new Cell(3,1).add(image3).setBorder(Border.NO_BORDER));
        table3.addCell(new Cell().add(new Paragraph("")).setBorder(Border.NO_BORDER));
        table3.addCell(new Cell().add(new Paragraph("")).setBorder(Border.NO_BORDER));

        document.add(table1);
        document.add(new Paragraph("\n"));
        document.add(table2);
        document.add(new Paragraph("\n\n\n\n\n\n(Authorised Signatory)\n\n\n").setTextAlignment(TextAlignment.RIGHT));
        document.add(table3);

        document.close();
        Toast.makeText(this,"Pdf Created",Toast.LENGTH_LONG).show();
    }
}