package com.example.uptm;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;

import androidx.appcompat.app.AppCompatActivity;

public class StudentHomepageActivity extends AppCompatActivity {

    ImageView feesImage,totalDues,compound;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_student_homepage);
        feesImage = findViewById(R.id.imageView4);
        totalDues = findViewById(R.id.imageView8);
        compound = findViewById(R.id.imageView10);

        String idValue = getIntent().getStringExtra("idValue");
        System.out.println("idValue received in StudentHomepage: " + idValue);


        feesImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(StudentHomepageActivity.this, StudentFeesActivity.class));
            }
        });

        totalDues.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), StudentTotalDuesActivity.class);
                intent.putExtra("idValue", idValue);
                startActivity(intent);
//                startActivity(new Intent(StudentHomepageActivity.this, StudentTotalDuesActivity.class));
            }
        });

        compound.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), StudentCompoundActivity.class);
                intent.putExtra("idValue", idValue);
                startActivity(intent);
//                startActivity(new Intent(StudentHomepageActivity.this, StudentTotalDuesActivity.class));
            }
        });
    }
}