package com.example.uptm;


import static android.content.ContentValues.TAG;


import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.app.ProgressDialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.os.Parcelable;
import android.provider.OpenableColumns;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.Toast;

//import com.google.android.gms.tasks.OnFailureListener;
//import com.google.android.gms.tasks.OnSuccessListener;
//import com.google.firebase.database.DatabaseReference;
//import com.google.firebase.database.FirebaseDatabase;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.firestore.FirebaseFirestore;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.concurrent.atomic.AtomicReference;

import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import javax.xml.XMLConstants;

public class AdminAddStudentActivity extends AppCompatActivity{
    private static final int PICK_FILE_REQUEST_CODE = 1;
    Button save,addFromExcel;
    EditText txtName,txtAddress;
//            txtCurrentSemester;

    String selectedType="";

    int countDiploma = 0;
    int countDegree = 0;
    int countProfessional = 0;

    String txtCurrentSemester="1";

    int semesterNum = 10;

    // Declare a boolean array to store the checked states
    boolean[] semesterPaidArray;
    List<Boolean> semesterPaidList;

    List<Boolean> semesterPaid = new ArrayList<>();

    int start = 0;

    Spinner spinnerCurrentSemester;

    String[] numberOfSemesterChoices = {"Currently semester 1", "Currently semester 2", "Currently semester 3", "Currently semester 4", "Currently semester 5", "Currently semester 6", "Currently semester 7", "Currently semester 8", "Currently semester 9", "Currently semester 10"};
    ArrayAdapter ad;

    ProgressDialog progressDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_add_student);


        save = findViewById(R.id.btnSave);
        addFromExcel = findViewById(R.id.btnAddFromExcel);
        txtName = findViewById(R.id.txtName);
        txtAddress = findViewById(R.id.txtAddress);
//        txtCurrentSemester = findViewById(R.id.txtCurrentSemester);

        setupCheckBoxes(semesterNum);

        spinnerCurrentSemester = findViewById(R.id.spinnerCurrentSemester);
        ad = new ArrayAdapter(this,android.R.layout.simple_spinner_item,numberOfSemesterChoices);
        ad.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerCurrentSemester.setAdapter(ad);
        spinnerCurrentSemester.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                txtCurrentSemester = numberOfSemesterChoices[i];
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });

        Spinner spinnerType = findViewById(R.id.spinnerType);
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
                R.array.student_types_array, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerType.setAdapter(adapter);

        spinnerType.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                selectedType = adapterView.getItemAtPosition(i).toString();
                if(selectedType.equals("Diploma")){
                    semesterNum = 10;
                    setupCheckBoxes(semesterNum);
                    // Update the number of semester choices for the spinner
                    numberOfSemesterChoices = new String[]{"Currently semester 1", "Currently semester 2", "Currently semester 3", "Currently semester 4", "Currently semester 5", "Currently semester 6", "Currently semester 7", "Currently semester 8", "Currently semester 9", "Currently semester 10"};
                }
                else if(selectedType.equals("Degree")){
                    semesterNum = 12;
                    setupCheckBoxes(semesterNum);
                    // Update the number of semester choices for the spinner
                    numberOfSemesterChoices = new String[]{"Currently semester 1", "Currently semester 2", "Currently semester 3", "Currently semester 4", "Currently semester 5", "Currently semester 6", "Currently semester 7", "Currently semester 8", "Currently semester 9", "Currently semester 10", "Currently semester 11", "Currently semester 12"};
                }
                else if(selectedType.equals("Professionals")){
                    semesterNum = 11;
                    setupCheckBoxes(semesterNum);
                    // Update the number of semester choices for the spinner
                    numberOfSemesterChoices = new String[]{"Currently semester 1", "Currently semester 2", "Currently semester 3", "Currently semester 4", "Currently semester 5", "Currently semester 6", "Currently semester 7", "Currently semester 8", "Currently semester 9", "Currently semester 10", "Currently semester 11"};
                }
                ad = new ArrayAdapter(getApplicationContext(), android.R.layout.simple_spinner_item, numberOfSemesterChoices);
                ad.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                spinnerCurrentSemester.setAdapter(ad);
                System.out.println("Selected: " + selectedType);
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });



//        spinnerType.on
//        txtType = findViewById(R.id.txtType);

        progressDialog = new ProgressDialog(this);
        progressDialog.setTitle("Please Wait..");
        progressDialog.setCanceledOnTouchOutside(false);

        save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                validateData();
            }
        });
        addFromExcel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                // Open file chooser
                Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
                intent.setType("*/*");
                startActivityForResult(intent, PICK_FILE_REQUEST_CODE);


            }
        });

    }



    public static String generateStudentId( String studentName) {
        LocalDate currentDate = LocalDate.now();
        DateTimeFormatter dateFormatter = DateTimeFormatter.ofPattern("yyyy");
        String dateString = dateFormatter.format(currentDate);
        String identifier = studentName.substring(0, Math.min(studentName.length(), 3)).toUpperCase();
        // Generate a random sequence number or use a unique identifier

        Random random = new Random();
        int sequenceNumber = random.nextInt(9000) + 1000; // Example: Random 4-digit number

        // Concatenate the year and identifier
        String studentId = dateString + "-" + identifier + "-" + sequenceNumber;

        return studentId;
    }

    private String getRealPathFromUri(Uri uri) {
        String filePath = null;
        Cursor cursor = getContentResolver().query(uri, null, null, null, null);
        if (cursor != null) {
            try {
                if (cursor.moveToFirst()) {
                    int nameIndex = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                    if (nameIndex != -1) {
                        String fileName = cursor.getString(nameIndex);
                        File file = new File(getCacheDir(), fileName);
                        InputStream inputStream = getContentResolver().openInputStream(uri);
                        if (inputStream != null) {
                            FileOutputStream outputStream = new FileOutputStream(file);
                            byte[] buffer = new byte[1024];
                            int length;
                            while ((length = inputStream.read(buffer)) > 0) {
                                outputStream.write(buffer, 0, length);
                            }
                            outputStream.close();
                            inputStream.close();
                            filePath = file.getAbsolutePath();
                        }
                    }
                }
            } catch (IOException e) {
                e.printStackTrace();
            } finally {
                cursor.close();
            }
        }
        return filePath;
    }




    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == PICK_FILE_REQUEST_CODE && resultCode == RESULT_OK && data != null) {
            // Get the file URI
            Uri fileUri = data.getData();

            String pathh = getRealPathFromUri(fileUri);

            // Get the file path from the URI
            String filePath = fileUri.getPath();
            System.out.println(pathh);
            // Use the file path to open the file using Apache POI
            FileInputStream fis = null;
            List<Student> studentList = new ArrayList<>();
            try {
//                int permission = ContextCompat.checkSelfPermission(this, android.Manifest.permission.READ_EXTERNAL_STORAGE);
                if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED) {
                    System.out.println("Permission granted");
                }
                else{
                    final int PERMISSION_REQUEST_CODE = 1;
                    ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.READ_EXTERNAL_STORAGE}, PERMISSION_REQUEST_CODE);
                }
//                filePath = filePath.replace("/document/raw:", "");
                fis = new FileInputStream(pathh);
                System.setProperty(XMLConstants.FEATURE_SECURE_PROCESSING, "false");

                Workbook workbook = new XSSFWorkbook(fis);
                Sheet sheet = workbook.getSheetAt(0);
                // Iterate over the rows and cells
                String name = "";
                String password = "test";
                String username = "test";
                String currentSemester = "2";
                String type = "degree";
                String address = "No 33 Jalan PJS 2C/2 Taman Setia";

                double compound = 0;
                int booleanTotal = 0;
                int cellNum = 1;

                for (Row row : sheet) {
                    booleanTotal = 0;
                    for (Cell cell : row) {
                        // Access the cell value
//                        System.out.println("current celltype cell.getCellType(): " + cell.getCellType());

//                            if(cellNum == 1){
//                                name = cell.getStringCellValue();
//                            }
//                            else if(cellNum == 2){
//                                currentSemester = String.valueOf(cell.getNumericCellValue());
//                            }
//                            else if(cellNum == 3){
//                                type = cell.getStringCellValue();
//                                if(type.equals("diploma")){
//                                    semesterPaid = new boolean[10];
//                                }
//                                else if(type.equals("degree")){
//                                    semesterPaid = new boolean[12];
//                                }
//                                else if(type.equals("professional")){
//                                    semesterPaid = new boolean[11];
//                                }
//                            }
//                            else if(cellNum == 4){
//                                compound = cell.getNumericCellValue();
//                            }
//                            else{
//                                boolean semPaid = cell.getBooleanCellValue();
//                                semesterPaid[cellNum-5] = semPaid;
//                            }

                        switch (cell.getCellType()) {
                            case STRING:
                                String cellValue = cell.getStringCellValue();
                                System.out.println("in loop");
                                System.out.println(cellValue);
                                if(!cellValue.contains("NAME") && !cellValue.contains("SEMESTER")&& !cellValue.contains("PAID")&& !cellValue.contains("TYPE")&& !cellValue.contains("COMPOUND")){
                                    System.out.println("not header");
                                    System.out.println("cellNum: " + cellNum);
                                    if(cellNum == 1){
                                        name = cell.getStringCellValue();
                                        username = generateStudentId(name);
                                        password = username;
                                    }
                                    else if(cellNum == 2){
                                        address = cell.getStringCellValue();
                                    }
                                    else if(cellNum == 4){
                                        type = cell.getStringCellValue();
                                        if(type.equals("diploma")){
//                                            semesterPaid = new ArrayList<>(Collections.nCopies(10, false));
                                        }
                                        else if(type.equals("degree")){
//                                            semesterPaid = new ArrayList<>(Collections.nCopies(12, false));
                                        }
                                        else if(type.equals("professional")){
//                                            semesterPaid = new ArrayList<>(Collections.nCopies(11, false));
                                        }
                                    }
//                                    if(cellValue.contains("0")){
//                                        if (cellValue.length() == 12 && cellValue.startsWith("01DDT") && (cellValue.charAt(7) == 'F' && (cellValue.charAt(8) == '1' || cellValue.charAt(8) == '2'))) {
//                                            // Format is valid
////                                            String name = "nametest";
//                                            String password = "test";
//                                            String username = "test";
//                                            String currentSemester = "2";
//                                            String type = "degree";
//                                            String address = "No 33 Jalan PJS 2C/2 Taman Setia";
//                                            boolean[] semesterPaid = new boolean[11]; // Initialize array with 11 elements for 11 semesters
//                                            double compound = 0;
//
//                                            // Initialize all semesters as unpaid (false)
//                                            for (int i = 0; i < semesterPaid.length; i++) {
//                                                semesterPaid[i] = false;
//                                            }
//
//                                            // Create a new Student object
//                                            Student student = new Student(name, password, username, currentSemester, type, address, semesterPaid,compound);
//                                            matrixNum = cellValue;
//                                            studentList.add(student);
//
//                                        } else {
//                                            // Format is not valid
//                                            Toast.makeText(this, "Invalid Student Matrix Number Format...", Toast.LENGTH_SHORT).show();
//                                            break;
//                                        }
//
//
//                                    }
//                                    else{
//                                        System.out.println("not contains 0");
//                                        name = cellValue;
//                                    }
                                }
                                else{

                                }

                                // Do something with the cell value
                                System.out.println(cellValue);
                                break;
                            case NUMERIC:
                                System.out.println("NUMERIC CASE");
                                System.out.println("cellNum: " + cellNum);
                                double numericCellValue = cell.getNumericCellValue();
                                // Do something with the numeric cell value
                                if(cellNum == 3){
                                    currentSemester = String.valueOf(cell.getNumericCellValue());
                                }
                                else if(cellNum == 5){
                                    compound = cell.getNumericCellValue();
                                }
                                System.out.println(numericCellValue);
                                break;
                            // Handle other cell types as needed
                            case BOOLEAN:
                                System.out.println("BOOLEAN CASE");
                                System.out.println("cellNum: " + cellNum);
                                boolean booleanCellValue = cell.getBooleanCellValue();

                                boolean semPaid = cell.getBooleanCellValue();
                                int currentSize = semesterPaid.size();
//                                System.out.println("currentSize before condition: " + currentSize);
                                if (type.equals("diploma")) {
                                    if (countDiploma < 9) {
                                        semesterPaid.add(booleanCellValue);
                                        countDiploma++;
                                    }
                                } else if (type.equals("degree")) {
                                    if (countDegree < 12) {
                                        semesterPaid.add(booleanCellValue);
                                        countDegree++;
                                    }
                                } else if (type.equals("professional")) {
                                    if (countProfessional < 10) {
                                        semesterPaid.add(booleanCellValue);
                                        countProfessional++;
                                    }
                                }

//                                System.out.println("currentSize after condition: " + semesterPaid.size());

                                booleanTotal++;

                                break;

                        }
                        cellNum++;
                    }



                    Student student = new Student(name, password, username, currentSemester, type, address, semesterPaid,compound);

                    if(!student.getName().equals("") || !student.getName().isEmpty()){
//                        System.out.println("in adminaddstudent declraing studentname:" +student.getName());
//                        System.out.println("in adminaddstudent declraing student:" +student.getSemesterPaid());
//                        System.out.println("in adminaddstudent declraing student size:" +student.getSemesterPaid().size());
                        studentList.add(student);
                    }
//                    semesterPaid.clear();
                    cellNum = 1;
                    countDegree = 0;
                    countDiploma = 0;
                    countProfessional = 0;
                    System.out.println("booleanTotal in one row: " + booleanTotal);

                }
                System.out.println("studentList.stream().count(): " + studentList.stream().count());
                // Do something with the sheet data
                // ...

            } catch (IOException e) {
                e.printStackTrace();
            } finally {
                if (fis != null) {
                    try {
                        fis.close();
                        Intent intent = new Intent(AdminAddStudentActivity.this, AdminAddStudentExcelTable.class);
                        intent.putExtra("StudentListSize",studentList.size());
                        intent.putParcelableArrayListExtra("studentList", new ArrayList<>(studentList));
                        // Wrap semesterPaid list with BooleanListWrapper
                        BooleanListWrapper wrapper = new BooleanListWrapper(semesterPaid);

                        // Pass the wrapped list as a Parcelable extra
                        intent.putExtra("semesterPaid", wrapper);
//                        ArrayList<ArrayList<Boolean>> paidList = new ArrayList<>();
                        System.out.println("in adminaddstudent Studentlist size: " + studentList.size());
                        System.out.println("starting start value: " + start);

                        studentList.forEach(student -> {
                            System.out.println("in adminaddstudent studentList getSemesterPaid() size: " + student.getSemesterPaid().size());
                            if (student.getType().equals("diploma")) {
                                System.out.println(student.getName());
                                int end = Math.min(start + 9, semesterPaid.size());
                                for (int i = start; i < end; i++) {
                                    System.out.println(semesterPaid.get(i));
                                }
                                start = end; // Update start based on the number of values processed
                            } else if (student.getType().equals("degree")) {
                                System.out.println(student.getName());
                                int end = Math.min(start + 11, semesterPaid.size());
                                for (int i = start; i < end; i++) {
                                    System.out.println(semesterPaid.get(i));
                                }
                                start = end; // Update start based on the number of values processed
                            } else if (student.getType().equals("professional")) {
                                System.out.println(student.getName());
                                int end = Math.min(start + 10, semesterPaid.size());
                                for (int i = start; i < end; i++) {
                                    System.out.println(semesterPaid.get(i));
                                }
                                start = end; // Update start based on the number of values processed
                            }
                            System.out.println("after start value: " + start);
                        });

                        System.out.println("after done all start value: " + start);
                        System.out.println("semesterPaid.size(): " + semesterPaid.size());
                        // Convert each inner ArrayList to ParcelableArrayList
//                        ArrayList<BooleanListParcelable> parcelablePaidList = new ArrayList<>();
//                        for (ArrayList<Boolean> innerList : paidList) {
//                            parcelablePaidList.add(new BooleanListParcelable(innerList));
//                        }


//                        intent.putParcelableArrayListExtra("paidList", parcelablePaidList);
//                        startActivity(intent);
                        startActivity(intent);
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            }
        }
    }



    private void validateData() {
        // Get the values from EditText fields
        String name = txtName.getText().toString().trim();
        String address = txtAddress.getText().toString().trim();
        String currentSemester = spinnerCurrentSemester.getSelectedItem().toString();
        currentSemester = currentSemester.replace("Currently semester ","");
        String type = selectedType;

        // Check if any of the fields are empty
        if (TextUtils.isEmpty(name)) {
            Toast.makeText(this, "Enter Student Name...", Toast.LENGTH_SHORT).show();
        } else if (TextUtils.isEmpty(address)) {
            Toast.makeText(this, "Enter Address...", Toast.LENGTH_SHORT).show();
        } else if (TextUtils.isEmpty(currentSemester)) {
            Toast.makeText(this, "Enter Current Semester...", Toast.LENGTH_SHORT).show();
        } else if (TextUtils.isEmpty(type)) {
            Toast.makeText(this, "Enter Type...", Toast.LENGTH_SHORT).show();
        } else {
            // All fields are filled, proceed to upload data
            String username = generateStudentId(name);
            uploadData(username,name,address,currentSemester,type);

        }
    }


    private void uploadData(String username,String name,String address,String currentSemester,String type) {
        semesterPaidList = new ArrayList<>();
        for(int i = 0; i<semesterPaidArray.length;i++){
            System.out.println("semesterPaidArray " + i + ": " + String.valueOf(semesterPaidArray[i]));
            semesterPaidList.add(semesterPaidArray[i]);
        }

        System.out.println("Username: " + username);
        System.out.println("name: " + name);
        System.out.println("address: " + address);
        System.out.println("currentSemester: " + currentSemester);
        System.out.println("type: " + type);


        progressDialog.setMessage("Saving Student Details...");
        progressDialog.show();




        Map<String, Object> studentData = new HashMap<>();
        studentData.put("username", username);
        studentData.put("password", username);
        studentData.put("address", address);
        studentData.put("name", name);
        studentData.put("currentSemester", currentSemester);
        studentData.put("type", type.toLowerCase().toString());
        studentData.put("compound", 0);
        studentData.put("semesterPaid", semesterPaidList);
        FirebaseFirestore db = FirebaseFirestore.getInstance();
        db.collection("users").document(username)
                .set(studentData)
                .addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void aVoid) {
                        Log.d(TAG, "DocumentSnapshot successfully written!");
                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Log.w(TAG, "Error writing document", e);
                    }
                });



        progressDialog.cancel();
        Toast.makeText(AdminAddStudentActivity.this, "Student Details Uploaded...", Toast.LENGTH_SHORT).show();
        finish();

    }

    private void createCheckBoxes(int numSemesters) {
        LinearLayout checkBoxContainer = findViewById(R.id.checkBoxContainer);

        // Clear existing checkboxes if any
        checkBoxContainer.removeAllViews();

        // Initialize the boolean array based on the number of semesters
        semesterPaidArray = new boolean[numSemesters];

        // Create and add checkboxes for each semester
        for (int i = 0; i < numSemesters; i++) {
            CheckBox checkBox = new CheckBox(this);
            checkBox.setText("Semester " + (i + 2) + " paid");
            checkBox.setChecked(false); // Set default state to false

            // Set a tag to identify which semester this checkbox represents
            checkBox.setTag(i);

            // Add a listener to update the boolean array when the checkbox state changes
            checkBox.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                @Override
                public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                    // Get the tag (semester index) of the checkbox
                    int semesterIndex = (int) buttonView.getTag();

                    // Update the corresponding value in the boolean array
                    semesterPaidArray[semesterIndex] = isChecked;
                }
            });

            // Add the checkbox to the layout
            checkBoxContainer.addView(checkBox);
        }
    }
    private void setupCheckBoxes(int numSemesters) {
        createCheckBoxes(numSemesters);
    }



}

