package com.example.uptm;


import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class AdminStudentAdapter extends RecyclerView.Adapter<AdminStudentAdapter.MyHolder>{

    Context context;
    List<StudentModel> studentModels;

    public AdminStudentAdapter(Context context, List<StudentModel> studentModelList) {
        this.context = context;
        this.studentModels = studentModelList;
    }

    @NonNull
    @Override
    public MyHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.show_user, parent , false);
        return new MyHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull MyHolder holder, int position) {

        String id = studentModels.get(position).getName();

        holder.showId.setText(id);

    }

    @Override
    public int getItemCount() {
        return studentModels.size();
    }

    class MyHolder extends RecyclerView.ViewHolder{

        TextView showId;

        public MyHolder(@NonNull View itemView) {
            super(itemView);

            showId =itemView.findViewById(R.id.ShowLecturerId);

            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Intent AdminUpdateStudentActivity = new Intent(context,AdminUpdateStudentActivity.class);
                    int position = getAdapterPosition();



                    AdminUpdateStudentActivity.putExtra("name",studentModels.get(position).getName());
                    AdminUpdateStudentActivity.putExtra("username",studentModels.get(position).getUsername());
                    AdminUpdateStudentActivity.putExtra("password",studentModels.get(position).getPassword());
                    AdminUpdateStudentActivity.putExtra("currentSemester",studentModels.get(position).getCurrentSemester());
                    AdminUpdateStudentActivity.putExtra("type",studentModels.get(position).getType());
                    AdminUpdateStudentActivity.putExtra("address",studentModels.get(position).getAddress());
                    BooleanListWrapper wrapper = new BooleanListWrapper(studentModels.get(position).getSemesterPaid());
                    AdminUpdateStudentActivity.putExtra("semesterPaid",wrapper);
                    AdminUpdateStudentActivity.putExtra("compound",studentModels.get(position).getCompound());
                    AdminUpdateStudentActivity.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    context.startActivity(AdminUpdateStudentActivity);

                }
            });

        }
    }

}



