package com.example.uptm;

import androidx.annotation.NonNull;

import androidx.appcompat.app.AppCompatActivity;

import androidx.appcompat.widget.SearchView;

import androidx.core.view.MenuItemCompat;

import androidx.recyclerview.widget.LinearLayoutManager;

import androidx.recyclerview.widget.RecyclerView;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;
//import com.google.firebase.database.DataSnapshot;
//import com.google.firebase.database.DatabaseError;
//import com.google.firebase.database.FirebaseDatabase;
//import com.google.firebase.database.Query;
//import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

public class AdminManageStudentActivity extends AppCompatActivity {

//    FloatingActionButton add;
    RecyclerView recyclerView;
    AdminStudentAdapter adminStudentAdapter;
    List<StudentModel> studentModels;

    private static final String TAG = "uptmSnippets";

//    TextView insertRegNum;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_manage_student);

//        insertRegNum =  findViewById(R.id.insertRegNum);

//        insertRegNum.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                startActivity(new Intent(AdminViewStudentActivity.this, AdminAddStudentActivity.class));
//                System.out.println("clicked insert reg");
//            }
//        });

//        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
//        getSupportActionBar().setTitle("Complaint Page");

//        add = findViewById(R.id.btnAddStudent);

//        add.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                startActivity(new Intent(AdminViewStudentActivity.this, AdminAddStudentActivity.class));
//            }
//        });

        recyclerView = findViewById(R.id.recyclerView);
        LinearLayoutManager layoutManager = new LinearLayoutManager(this);
        layoutManager.setStackFromEnd(true);
        layoutManager.setReverseLayout(true);
        recyclerView.setLayoutManager(layoutManager);
        studentModels = new ArrayList<>();

        all();

    }

    private void all() {

        FirebaseFirestore mFirestore = FirebaseFirestore.getInstance();
        mFirestore.collection("users")
                .get()
                .addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                    @Override
                    public void onComplete(@NonNull Task<QuerySnapshot> task) {
                        if (task.isSuccessful()) {
                            for (QueryDocumentSnapshot document : task.getResult()) {
                                Log.d(TAG, document.getId() + " => " + document.getData());

                                String passwordFromFirestore = document.getString("password");
                                if(!document.getId().contains("admin") ){
                                    String name = document.getString("name");
                                    String password = document.getString("password");
                                    String username = document.getString("username");
                                    String currentSemester = document.getString("currentSemester");
                                    String type = document.getString("type");
                                    String address = document.getString("address");

                                    // Assuming the "semesterPaid" field in Firestore is an array of booleans
                                    List<Boolean> semesterPaid = (List<Boolean>) document.get("semesterPaid");
                                    // Assuming the "compound" field in Firestore is a double
                                    double compound = document.getDouble("compound");

                                    StudentModel studentModel = new StudentModel(name, password, username, currentSemester, type, address, semesterPaid, compound);
                                    studentModels.add(studentModel);
                                    adminStudentAdapter = new AdminStudentAdapter(getApplicationContext(), studentModels);
                                    recyclerView.setAdapter(adminStudentAdapter);

//                                    Toast.makeText(LoginActivity.this, "Login Successfully", Toast.LENGTH_SHORT).show();
//                                    startActivity(new Intent(LoginActivity.this, AdminHomeActivity.class));
//                                    break;
                                }
//                                else if(document.getId().equals(ID) && passwordFromFirestore.equals(password)){
//                                    System.out.println("matches: " + ID + " " + password);
//                                    Toast.makeText(LoginActivity.this, "Login Successfully", Toast.LENGTH_SHORT).show();
//                                    Intent intent = new Intent(getApplicationContext(), StudentHomepageActivity.class);
//                                    intent.putExtra("idValue", ID);
//                                    startActivity(intent);
////                                        startActivity(new Intent(LoginActivity.this, StudentHomepageActivity.class));
//                                    break;
//                                }
//                                else{
//                                    System.out.println("not match: " + ID + " " + password);
//                                }
                            }
//                            progressDialog.cancel();
                        } else {
                            Log.d(TAG, "Error getting documents: ", task.getException());
                        }
                    }
                });
//        Query ref;
//
//        ref = FirebaseDatabase.getInstance().getReference("Student");
//
//        ref.addValueEventListener(new ValueEventListener() {
//            @Override
//            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
//                studentModels.clear();
//                for (DataSnapshot ds: dataSnapshot.getChildren()){
//                    StudentModel studentModel = ds.getValue(StudentModel.class);
//                    studentModels.add(studentModel);
//                    adminStudentAdapter = new AdminStudentAdapter(getApplicationContext(), studentModels);
//                    recyclerView.setAdapter(adminStudentAdapter);
//                }
//            }
//
//            @Override
//            public void onCancelled(@NonNull DatabaseError databaseError) {
//
//            }
//        });

    }

    private void firebaseSearch(String searchtext){

//        Query ref;
//
//        ref = FirebaseDatabase.getInstance().getReference("Student");
//        String query = searchtext;
//        Query firebaseQuery= ref.orderByChild("StuMatrixNumber").startAt(query).endAt(query+"\uf8ff");
//
//        studentModels = new ArrayList<>();
//        adminStudentAdapter = new AdminStudentAdapter(this,studentModels);
//        recyclerView.setAdapter(adminStudentAdapter);
//
//        firebaseQuery.addValueEventListener(new ValueEventListener() {
//            @Override
//            public void onDataChange(@NonNull DataSnapshot snapshot) {
//
//                for (DataSnapshot dataSnapshot : snapshot.getChildren()){
//
//                    StudentModel studentModel = dataSnapshot.getValue(StudentModel.class);
//                    studentModels.add(studentModel);
//
//                }
//                adminStudentAdapter.notifyDataSetChanged();
//
//            }
//
//            @Override
//            public void onCancelled(@NonNull DatabaseError error) {
//
//            }
//        });

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main_menu,menu);
        MenuItem item = menu.findItem(R.id.search_firebase);
        androidx.appcompat.widget.SearchView searchView = (androidx.appcompat.widget.SearchView) MenuItemCompat.getActionView(item);
        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                firebaseSearch(query);
                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                firebaseSearch(newText);
                return false;
            }
        });
        return super.onCreateOptionsMenu(menu);
    }

}