package com.example.uptm;


import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.text.method.PasswordTransformationMethod;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.Query;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;
//import com.google.firebase.database.DataSnapshot;
//import com.google.firebase.database.DatabaseError;
//import com.google.firebase.database.DatabaseReference;
//import com.google.firebase.database.FirebaseDatabase;
//import com.google.firebase.database.ValueEventListener;

import java.util.Base64;
import java.util.Random;

import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;

public class LoginActivity extends AppCompatActivity {
    private static final String TAG = "uptmSnippets";
    Button login;

    TextView forgot;
    EditText txtId,txtPassword;
    ProgressDialog progressDialog;
//    private DatabaseReference mDatabase;
    private FirebaseFirestore mFirestore;
    private DocumentReference mRestaurantRef;
    TextInputLayout passwordInputLayout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        mFirestore = FirebaseFirestore.getInstance();


        login = findViewById(R.id.login_btn);
        txtId = findViewById(R.id.username_input);
        txtPassword = findViewById(R.id.password_input);

        txtPassword.setTransformationMethod(PasswordTransformationMethod.getInstance());
        // Set the click listener to toggle password visibility
//        passwordInputLayout.setEndIconOnClickListener(new View.OnClickListener() {
//            boolean isPasswordVisible = false;
//
//            @Override
//            public void onClick(View v) {
//                if (isPasswordVisible) {
//                    // Hide the password
//                    txtPassword.setTransformationMethod(PasswordTransformationMethod.getInstance());
//                    passwordInputLayout.setEndIconDrawable(R.drawable.baseline_visibility_off_24); // Set the show password icon
//                } else {
//                    // Show the password
//                    txtPassword.setTransformationMethod(null);
//                    passwordInputLayout.setEndIconDrawable(R.drawable.baseline_visibility_24); // Set the hide password icon
//                }
//                isPasswordVisible = !isPasswordVisible; // Toggle the state
//            }
//        });

        progressDialog = new ProgressDialog(this);
        progressDialog.setTitle("Please Wait..");
        progressDialog.setCanceledOnTouchOutside(false);

        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try {
                    validate();
                } catch (Exception e) {
                    throw new RuntimeException(e);
                }
            }
        });

//        forgot.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                forgotPassword();
//            }
//        });

    }


    private void forgotPassword(){
        String idValue = txtId.getText().toString();
//        Intent intent = new Intent(LoginActivity.this, ForgotPasswordActivity.class);
//        intent.putExtra("idValue",idValue);
//        startActivity(intent);
    }

    private String id = "",Password = "";
    private void validate() throws Exception {

        id = txtId.getText().toString().trim();
        Password = txtPassword.getText().toString().trim();

        if (TextUtils.isEmpty(id)){
            Toast.makeText(this, "Enter Your Id...", Toast.LENGTH_SHORT).show();
        }
        else if (TextUtils.isEmpty(Password)){
            Toast.makeText(this, "Enter Your Password...", Toast.LENGTH_SHORT).show();
        }
        else {
            loginUser();
        }

    }









    Boolean loggedIn = false;
    private void loginUser() throws Exception {

        String AdUsername = "admin";
        String AdPassword = "admin";

        try {



            progressDialog.setMessage("Logging In...");
            progressDialog.show();

            String ID = txtId.getText().toString();
            String password = txtPassword.getText().toString();



            mFirestore.collection("users")
                    .get()
                    .addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                        @Override
                        public void onComplete(@NonNull Task<QuerySnapshot> task) {
                            if (task.isSuccessful()) {
                                for (QueryDocumentSnapshot document : task.getResult()) {
                                    Log.d(TAG, document.getId() + " => " + document.getData());

                                    String passwordFromFirestore = document.getString("password");
                                    if(ID.contains("admin") && document.getId().equals(ID) && passwordFromFirestore.equals(password)){
                                        loggedIn = true;
                                        Toast.makeText(LoginActivity.this, "Login Successfully", Toast.LENGTH_SHORT).show();
                                        startActivity(new Intent(LoginActivity.this, AdminHomeActivity.class));
                                        break;
                                    }
                                    else if(document.getId().equals(ID) && passwordFromFirestore.equals(password)){
                                        loggedIn = true;
                                        System.out.println("matches: " + ID + " " + password);
                                        Toast.makeText(LoginActivity.this, "Login Successfully", Toast.LENGTH_SHORT).show();
                                        Intent intent = new Intent(getApplicationContext(), StudentHomepageActivity.class);
                                        intent.putExtra("idValue", ID);
                                        startActivity(intent);
//                                        startActivity(new Intent(LoginActivity.this, StudentHomepageActivity.class));
                                        break;
                                    }
                                    else{

                                        System.out.println("not match: " + ID + " " + password);
                                    }
                                }
                                progressDialog.cancel();
                                System.out.println("loggedIn: "+loggedIn);
                                if(!loggedIn){
                                    Toast.makeText(LoginActivity.this, "Wrong username or password", Toast.LENGTH_SHORT).show();
                                }
                            } else {
                                Log.d(TAG, "Error getting documents: ", task.getException());
                            }
                        }
                    });


            } catch (Exception e) {
                e.printStackTrace();
            }



    }

    public void forgotPass(View view) {
        forgotPassword();
    }
}