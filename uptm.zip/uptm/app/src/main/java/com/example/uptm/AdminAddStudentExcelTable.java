package com.example.uptm;

import static android.content.ContentValues.TAG;

import static com.example.uptm.AdminAddStudentActivity.generateStudentId;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;
//import com.google.firebase.database.DataSnapshot;
//import com.google.firebase.database.DatabaseError;
//import com.google.firebase.database.DatabaseReference;
//import com.google.firebase.database.FirebaseDatabase;
//import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicInteger;

public class AdminAddStudentExcelTable extends AppCompatActivity {
    Button btnSubmit;

//    private DatabaseReference mDatabase;
    ProgressDialog progressDialog;

    int start = 0;

    List<Boolean> semesterPaid;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_add_student_excel_table);
        TableLayout tableLayout = findViewById(R.id.tableLayout);
        btnSubmit = findViewById(R.id.submitButton);
//        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
//        getSupportActionBar().setTitle("Student List From Excel");

        progressDialog = new ProgressDialog(this);
        progressDialog.setTitle("Please Wait..");
        progressDialog.setCanceledOnTouchOutside(false);

        Intent intent = getIntent();
        ArrayList<Student> studentList = intent.getParcelableArrayListExtra("studentList");
        BooleanListWrapper booleanListWrapper = intent.getParcelableExtra("semesterPaid");

        // Check if the BooleanListWrapper is not null
        if (booleanListWrapper != null) {
            System.out.println("semesterPaid received in adminaddstudentexceltable not null");
            // Retrieve the ArrayList<Boolean> from BooleanListWrapper
            semesterPaid = booleanListWrapper.getBooleanList();

            studentList.forEach(student -> {
                List<Boolean> semesterPaidForStudent = new ArrayList<>();
                System.out.println("in adminaddstudent studentList getSemesterPaid() size: " + student.getSemesterPaid().size());
                if (student.getType().equals("diploma")) {
                    System.out.println(student.getName());
                    int end = Math.min(start + 9, semesterPaid.size());
                    for (int i = start; i < end; i++) {
                        System.out.println(semesterPaid.get(i));
                        semesterPaidForStudent.add(semesterPaid.get(i));
                    }
                    student.setSemesterPaid(semesterPaidForStudent);
                    start = end; // Update start based on the number of values processed
                } else if (student.getType().equals("degree")) {
                    System.out.println(student.getName());
                    int end = Math.min(start + 11, semesterPaid.size());
                    for (int i = start; i < end; i++) {
                        System.out.println(semesterPaid.get(i));
                        semesterPaidForStudent.add(semesterPaid.get(i));
                    }
                    student.setSemesterPaid(semesterPaidForStudent);
                    start = end; // Update start based on the number of values processed
                } else if (student.getType().equals("professional")) {
                    System.out.println(student.getName());
                    int end = Math.min(start + 10, semesterPaid.size());
                    for (int i = start; i < end; i++) {
                        System.out.println(semesterPaid.get(i));
                        semesterPaidForStudent.add(semesterPaid.get(i));
                    }
                    student.setSemesterPaid(semesterPaidForStudent);
                    start = end; // Update start based on the number of values processed
                }
                System.out.println("after start value: " + start);
            });

            // Now you have the ArrayList<Boolean> to work with
            // Do whatever you need to do with the semesterPaid list
            // ...
        } else {
            System.out.println("semesterPaid received in adminaddstudentexceltable null");
            // Handle the case when the BooleanListWrapper is null
            // ...
        }
//        for(int i = 0;i<studentList.size();i++){
//
//        }



        studentList.forEach(student -> {
            System.out.println("student received in adminaddstudentexceltable");
            System.out.println(student.getName());
            System.out.println(student.getAddress());
            System.out.println(student.getType());
            System.out.println(student.getCurrentSemester());
            student.getSemesterPaid().forEach(semester -> {
                System.out.println("semester received: " + semester);
            });
        });
        // Check if the TableLayout is null
        if (tableLayout != null) {
            // Access and modify the TableLayout
            for (Student student : studentList) {
                TableRow tableRow = new TableRow(this);
                // Add views to the TableRow
                TextView nameTextView = new TextView(this);
                nameTextView.setText(student.getName());
                nameTextView.setTextSize(15);
                nameTextView.setPadding(10,10,10,10);
                tableRow.addView(nameTextView);

//                TextView matrixNumTextView = new TextView(this);
//                matrixNumTextView.setText(student.getCurrentSemester());
//                matrixNumTextView.setTextSize(15);
//                matrixNumTextView.setPadding(10,10,10,10);
//                tableRow.addView(matrixNumTextView);

//                Button deleteButton = new Button(this);
//                deleteButton.setText("Delete");
//                deleteButton.setOnClickListener(new View.OnClickListener() {
//                    @Override
//                    public void onClick(View view) {
//                        // Get the parent row of the clicked button
//                        TableRow parentRow = (TableRow) view.getParent();
//
//                        // Get the index of the parent row within the TableLayout
//                        int rowIndex = tableLayout.indexOfChild(parentRow);
//
//                        // Remove the corresponding student from the studentList
//                        if (rowIndex >= 0 && rowIndex < studentList.size()) {
//                            studentList.remove(rowIndex);
//                        }
//
//                        // Remove the TableRow from the TableLayout
//                        tableLayout.removeView(parentRow);
//                        System.out.println(studentList.stream().count());
//                    }
//                });
////                deleteButton.setPadding(3,10,10,10);
//                deleteButton.setTextSize(10);
//                tableRow.addView(deleteButton);
                // Add the TableRow to the TableLayout
                tableLayout.addView(tableRow);
            }
        }
        else{
            System.out.println("tablelayout is null");
        }

        btnSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                final AtomicInteger numSubmit = new AtomicInteger(0);
                int totalStudents = studentList.size();

                for (Student student : studentList) {
                    checkStudent(student, new StudentCheckCallback() {
                        @Override
                        public void onStudentChecked(boolean isStudentFound) {
                            System.out.println("in btnSubmit");
                            System.out.println("isStudentFound: " + isStudentFound);
                            if (!isStudentFound) {
                                int count = numSubmit.incrementAndGet();
                                System.out.println("student id: " + student.getName() + " numSubmit: " + count);
                                List<Boolean> paid = student.getSemesterPaid();
                                System.out.println("paid.size: "+ paid.size());
                                paid.forEach(pa->{
                                    System.out.println("pa: " + pa);
                                });
                                uploadData(student);

                                // Check if all asynchronous tasks are completed
                                if (count == totalStudents) {
                                    // All tasks completed, proceed with the code after the loop
                                    System.out.println("All tasks completed");
                                    if (numSubmit.get() == 0) {
                                        Toast.makeText(AdminAddStudentExcelTable.this, "No New Student(s) To Add...", Toast.LENGTH_SHORT).show();
//                                        startActivity(new Intent(AdminAddStudentExcelTable.this, AdminHomeActivity.class));
//                                        finish();
                                    } else {
                                        // Handle the case when new student(s) added
                                    }
                                    Toast.makeText(AdminAddStudentExcelTable.this, "Successfully added", Toast.LENGTH_SHORT).show();
                                    finish();
                                }
                            }
                            else{
                                int count = numSubmit.incrementAndGet();
                                // Check if all asynchronous tasks are completed
                                if (count == totalStudents) {
                                    // All tasks completed, proceed with the code after the loop
                                    System.out.println("All tasks completed");
                                    Toast.makeText(AdminAddStudentExcelTable.this, "No New Student(s) To Add...", Toast.LENGTH_SHORT).show();
//                                    startActivity(new Intent(AdminAddStudentExcelTable.this, AdminHomeActivity.class));
//                                    finish();
//                                    if (numSubmit.get()-1 == 0) {
//
//                                    } else {
//                                        System.out.println(String.valueOf(numSubmit.get()));
//                                        // Handle the case when new lecturer(s) added
//                                    }
                                }
                            }
                        }
                    });
                }
//                finish();
//                finish();
            }
        });


    }

    public interface StudentCheckCallback {
        void onStudentChecked(boolean isStudentFound);
    }


    private void checkStudent(Student student, StudentCheckCallback callback) {
        System.out.println("in check student");
        System.out.println();
        FirebaseFirestore mFirestore = FirebaseFirestore.getInstance();

        mFirestore.collection("users")
                .get()
                .addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                    @Override
                    public void onComplete(@NonNull Task<QuerySnapshot> task) {
                        if (task.isSuccessful()) {
                            boolean isStudentFound = false;
                            for (QueryDocumentSnapshot document : task.getResult()) {
                                Log.d(TAG, document.getId() + " => " + document.getData());

                                 if(document.getString("name").equals(student.getName())){
                                    System.out.println("matches: " + student.getName());
                                     isStudentFound = true;
                                    break;
                                }
                                else{
                                    System.out.println("not match: " + student.getName());
                                }
                            }
                            callback.onStudentChecked(isStudentFound);
                        } else {
                            Log.d(TAG, "Error getting documents: ", task.getException());
                        }
                    }
                });

//        mDatabase = FirebaseDatabase.getInstance().getReference();
//        DatabaseReference usersRef = mDatabase.child("Student");
//        usersRef.addListenerForSingleValueEvent(new ValueEventListener() {
//            @Override
//            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
//                boolean isStudentFound = false;
//                for (DataSnapshot userSnapshot : dataSnapshot.getChildren()) {
//                    String storedStuMatrixNumber = userSnapshot.child("StuMatrixNumber").getValue(String.class);
//                    String storedStuName = userSnapshot.child("StuName").getValue(String.class);
//
//                    if (name.equals(storedStuName) && matrixNum.equals(storedStuMatrixNumber)) {
//                        isStudentFound = true;
//                        break;
//                    }
//                }
//                callback.onStudentChecked(isStudentFound);
//            }
//
//            @Override
//            public void onCancelled(@NonNull DatabaseError databaseError) {
//                // Handle any database error if necessary
//            }
//        });
    }


    private void uploadData(Student student) {

        progressDialog.setMessage("Saving Student Details...");
        progressDialog.show();

//        String timestamp = String.valueOf(System.currentTimeMillis());

//        HashMap<String, Object> hashMap = new HashMap<>();
//        hashMap.put("StuMatrixNumber",matrixNum);
//        hashMap.put("StuName",name);
//        hashMap.put("StuTimestamp",timestamp);
        String username = generateStudentId(student.getName());
        Map<String, Object> studentData = new HashMap<>();
        studentData.put("username", username);
        studentData.put("password", username);
        studentData.put("address", student.getAddress());
        studentData.put("name", student.getName());
        studentData.put("currentSemester", String.valueOf((int) Float.parseFloat(student.getCurrentSemester())));
        studentData.put("type", student.getType());
        studentData.put("compound", student.getCompound());
        studentData.put("semesterPaid", student.getSemesterPaid());
        FirebaseFirestore db = FirebaseFirestore.getInstance();
        db.collection("users").document(username)
                .set(studentData)
                .addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void aVoid) {
//                        progressDialog.dismiss();
//                        finish();
                        Log.d(TAG, "DocumentSnapshot successfully written!");
                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Log.w(TAG, "Error writing document", e);
                    }
                });

//        DatabaseReference ref = FirebaseDatabase.getInstance().getReference("Student");
//        ref.child(timestamp)
//                .setValue(hashMap)
//                .addOnSuccessListener(new OnSuccessListener<Void>() {
//                    @Override
//                    public void onSuccess(Void unused) {
//
//                        progressDialog.dismiss();
//                        Toast.makeText(AdminAddStudentExcelTable.this, "Student Details Uploaded...", Toast.LENGTH_SHORT).show();
//                        startActivity(new Intent(AdminAddStudentExcelTable.this,AdminHomeActivity.class));
//                        finish();
//                    }
//                }).addOnFailureListener(new OnFailureListener() {
//                    @Override
//                    public void onFailure(@NonNull Exception e) {
//
//                        progressDialog.dismiss();
//                        Toast.makeText(AdminAddStudentExcelTable.this, ""+e.getMessage(), Toast.LENGTH_SHORT).show();
//                    }
//                });
        progressDialog.dismiss();
    }


}

