package com.example.uptm;

import android.os.Parcel;
import android.os.Parcelable;

import androidx.annotation.NonNull;

import java.util.ArrayList;
import java.util.List;

public class Student implements Parcelable {
    private String name;
    private String password;
    private String username;
    private String currentSemester;
    private String type;
    private String address;
    private List<Boolean> semesterPaid;
    private double compound;

    public Student(String name, String password, String username, String currentSemester,
                   String type, String address, List<Boolean> semesterPaid,double compound) {
        this.name = name;
        this.password = password;
        this.username = username;
        this.currentSemester = currentSemester;
        this.type = type;
        this.address = address;
        this.semesterPaid = semesterPaid;
        this.compound = compound;
    }

    protected Student(Parcel in) {
        name = in.readString();
        password = in.readString();
        username = in.readString();
        currentSemester = in.readString();
        type = in.readString();
        address = in.readString();
        compound = in.readDouble();

        // Deserialize semesterPaid list
        int[] semesterPaidArray = in.createIntArray();
        semesterPaid = new ArrayList<>();
        for (int i = 0; i < semesterPaidArray.length; i++) {
            semesterPaid.add(semesterPaidArray[i] == 1); // Convert integers to booleans
        }
    }

    public static final Creator<Student> CREATOR = new Creator<Student>() {
        @Override
        public Student createFromParcel(Parcel in) {
            return new Student(in);
        }

        @Override
        public Student[] newArray(int size) {
            return new Student[size];
        }
    };

    public String getName() {
        return name;
    }

    public String getPassword() {
        return password;
    }

    public String getUsername() {
        return username;
    }

    public String getCurrentSemester() {
        return currentSemester;
    }

    public String getType() {
        return type;
    }

    public String getAddress() {
        return address;
    }

    public List<Boolean> getSemesterPaid() {
        return semesterPaid;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public void setCurrentSemester(String currentSemester) {
        this.currentSemester = currentSemester;
    }

    public void setType(String type) {
        this.type = type;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public void setSemesterPaid(List<Boolean> semesterPaid) {
        this.semesterPaid = semesterPaid;
    }
    public double getCompound() {
        return compound;
    }

    public void setCompound(double compound) {
        this.compound = compound;
    }

    public int getTotalSemesters() {
        switch (type) {
            case "diploma":
                return 10;
            case "degree":
                return 12;
            case "professional":
                return 11;
            default:
                return 0;
        }
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(name);
        dest.writeString(password);
        dest.writeString(username);
        dest.writeString(currentSemester);
        dest.writeString(type);
        dest.writeString(address);
        dest.writeDouble(compound);

        // Serialize semesterPaid list
        int[] semesterPaidArray = new int[semesterPaid.size()];
        for (int i = 0; i < semesterPaid.size(); i++) {
            semesterPaidArray[i] = semesterPaid.get(i) ? 1 : 0; // Convert booleans to integers
        }
        dest.writeIntArray(semesterPaidArray);
    }

}

