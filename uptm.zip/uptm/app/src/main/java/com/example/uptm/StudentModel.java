package com.example.uptm;

import android.os.Parcel;
import android.os.Parcelable;

import androidx.annotation.NonNull;

import java.util.ArrayList;
import java.util.List;

public class StudentModel {
    private String name;
    private String password;
    private String username;
    private String currentSemester;
    private String type;
    private String address;
    private List<Boolean> semesterPaid;
    private double compound;

    public StudentModel(){}

    public StudentModel(String name, String password, String username, String currentSemester,
                   String type, String address, List<Boolean> semesterPaid,double compound) {
        this.name = name;
        this.password = password;
        this.username = username;
        this.currentSemester = currentSemester;
        this.type = type;
        this.address = address;
        this.semesterPaid = semesterPaid;
        this.compound = compound;
    }





    public String getName() {
        return name;
    }

    public String getPassword() {
        return password;
    }

    public String getUsername() {
        return username;
    }

    public String getCurrentSemester() {
        return currentSemester;
    }

    public String getType() {
        return type;
    }

    public String getAddress() {
        return address;
    }

    public List<Boolean> getSemesterPaid() {
        return semesterPaid;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public void setCurrentSemester(String currentSemester) {
        this.currentSemester = currentSemester;
    }

    public void setType(String type) {
        this.type = type;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public void setSemesterPaid(List<Boolean> semesterPaid) {
        this.semesterPaid = semesterPaid;
    }
    public double getCompound() {
        return compound;
    }

    public void setCompound(double compound) {
        this.compound = compound;
    }

    public int getTotalSemesters() {
        switch (type) {
            case "diploma":
                return 10;
            case "degree":
                return 12;
            case "professional":
                return 11;
            default:
                return 0;
        }
    }



}

