package com.example.uptm;

import android.os.Parcel;
import android.os.Parcelable;

import java.util.ArrayList;
import java.util.List;

public class BooleanListWrapper implements Parcelable {
    private List<Boolean> booleanList;

    public BooleanListWrapper(List<Boolean> booleanList) {
        this.booleanList = booleanList;
    }

    public List<Boolean> getBooleanList() {
        return booleanList;
    }

    protected BooleanListWrapper(Parcel in) {
        booleanList = new ArrayList<>();
        in.readList(booleanList, Boolean.class.getClassLoader());
    }

    public static final Creator<BooleanListWrapper> CREATOR = new Creator<BooleanListWrapper>() {
        @Override
        public BooleanListWrapper createFromParcel(Parcel in) {
            return new BooleanListWrapper(in);
        }

        @Override
        public BooleanListWrapper[] newArray(int size) {
            return new BooleanListWrapper[size];
        }
    };

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeList(booleanList);
    }
}
